<h1 align="center">🏠 House Price Prediction</h1>

<p align="center">
  <em>An end-to-end machine learning project that predicts residential property prices —
  from raw data to a deployed interactive web app.</em>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.11-3776AB?logo=python&logoColor=white" />
  <img src="https://img.shields.io/badge/scikit--learn-F7931E?logo=scikit-learn&logoColor=white" />
  <img src="https://img.shields.io/badge/Streamlit-FF4B4B?logo=streamlit&logoColor=white" />
  <img src="https://img.shields.io/badge/license-MIT-green" />
</p>

---

## 📊 Results at a glance

| Metric | Value | Meaning |
|--------|-------|---------|
| **R²** | **0.91** | 91% of price variance explained |
| **MAE** | **$14,897** | Average absolute error |
| **MAPE** | **8.9%** | Average percentage error |
| **CV RMSE (log)** | **0.1286** | Competition metric (RMSLE) |

Best model: **Gradient Boosting**, selected from a 3-model bake-off via 5-fold cross-validation.
The engineered **`TotalSF`** feature turned out to be the single strongest predictor.

---

## 🎯 What this project demonstrates
- **Real EDA** → insights that drive the modelling (log-transform, structural missingness, location signal)
- **Leak-free pipeline** → cleaning, feature engineering, imputation, scaling, and encoding all inside one `sklearn` Pipeline
- **Domain feature engineering** → 8 derived features, with the top one beating every raw column
- **Honest evaluation** → cross-validation + held-out test, reported in both log and dollar terms
- **A deployed product** → an interactive Streamlit app, plus configs to host it live

---

## 📁 Repository structure
```
house-price-prediction/
├── data/                      # Ames dataset (train.csv, test.csv)
├── notebooks/
│   ├── 01_EDA.ipynb           # exploratory data analysis
│   └── 02_Modeling.ipynb      # model building walkthrough
├── src/
│   ├── config.py              # paths & constants
│   ├── data_preprocessing.py  # loading + domain-driven cleaning
│   ├── feature_engineering.py # custom sklearn transformer (8 features)
│   ├── train.py               # train, cross-validate, select, save
│   ├── predict.py             # generate submission.csv
│   └── eda.py                 # produce all EDA figures
├── app/
│   └── streamlit_app.py       # interactive web app
├── reports/
│   ├── figures/               # all generated plots
│   ├── generate_report.py     # builds the PDF
│   └── House_Price_Prediction_Report.pdf
├── presentation/
│   ├── build_deck.js          # builds the slides
│   └── House_Price_Prediction.pptx
├── deployment/                # Dockerfile, Procfile, Streamlit config, DEPLOYMENT.md
├── docs/
│   ├── RESUME.md              # ready-to-use resume bullets
│   └── INTERVIEW_PREPARATION.md
├── models/                    # saved pipeline (after training)
├── requirements.txt
└── README.md
```

---

## 🚀 Quickstart
```bash
# 1. Install
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 2. Reproduce the model (trains, cross-validates, saves to models/)
python src/train.py

# 3. Generate the Kaggle submission
python src/predict.py

# 4. Launch the interactive app
streamlit run app/streamlit_app.py
```

Regenerate the EDA figures or the PDF report anytime:
```bash
python src/eda.py
python reports/generate_report.py
```

---

## 🔬 Approach in brief
1. **EDA** — `SalePrice` is right-skewed (→ log transform); 19 columns have missing values, many
   meaning "feature absent"; quality, living area, and neighbourhood drive price.
2. **Preprocessing** — structural NaNs → `None`/`0`; lot frontage → neighbourhood median; the rest
   imputed inside the pipeline to avoid leakage.
3. **Feature engineering** — `TotalSF`, `TotalBath`, `HouseAge`, `SinceRemodel`, porch totals, and
   has-pool/garage/fireplace flags (87 features after encoding).
4. **Modelling** — Ridge vs Random Forest vs Gradient Boosting, 5-fold CV on log-RMSE.
5. **Deployment** — Streamlit app + Docker/Cloud configs (see `deployment/DEPLOYMENT.md`).

---

## 📦 Deliverables in this repo
EDA notebook · modular training code · trained model · Kaggle submission · interactive Streamlit
app · **PDF project report** · **PowerPoint deck** · résumé bullets · interview prep · deployment guide.

## 🛠️ Tech stack
Python · pandas · NumPy · scikit-learn · matplotlib · seaborn · Streamlit · Docker

## 📄 License
MIT — see [LICENSE](LICENSE). Dataset © Kaggle / Dean De Cock (Ames Housing).
