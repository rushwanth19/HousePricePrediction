# Data

This folder holds the Ames housing dataset (Kaggle, *House Prices: Advanced Regression
Techniques*).

- `train.csv` — 1,460 labelled homes (includes the `SalePrice` target)
- `test.csv` — 1,459 homes for prediction (no target)

If you clone this repo without the data, download it from:
https://www.kaggle.com/competitions/house-prices-advanced-regression-techniques/data
and place both CSVs here.

Column descriptions are in the competition's `data_description.txt`.
