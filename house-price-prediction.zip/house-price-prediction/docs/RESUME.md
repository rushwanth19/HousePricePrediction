# Resume — House Price Prediction Project

Copy-paste-ready descriptions at three lengths. Replace metrics only if you retrain and they change.

---

## One-liner (skills/summary section)
Built an end-to-end house-price regression model (Gradient Boosting, R² = 0.91) with a
deployed Streamlit app, using scikit-learn pipelines and custom feature engineering.

---

## Standard (2–3 bullets — recommended for the projects section)

**House Price Prediction** — *Python, scikit-learn, pandas, Streamlit*
- Built an end-to-end regression pipeline on the Ames housing dataset (1,460 homes, 79 features),
  achieving **R² = 0.91** and **8.9% mean error** with a Gradient Boosting model.
- Engineered 8 domain-driven features (total square footage, total baths, house age); the
  engineered **TotalSF feature became the model's strongest predictor**.
- Compared Ridge, Random Forest, and Gradient Boosting via 5-fold cross-validation and
  **deployed an interactive Streamlit web app** for live price estimates.

---

## Detailed (STAR-style, for a portfolio page or to talk through in interviews)

**Situation.** Residential property valuation is slow, manual, and inconsistent.

**Task.** Predict home sale prices from 79 descriptive features, optimising RMSE on log price.

**Action.**
- Performed EDA: found a right-skewed target (applied a log transform) and 19 columns with
  missing values, many of which were structurally absent (no pool/garage) rather than unknown.
- Built a leak-free scikit-learn Pipeline: domain-driven cleaning → feature engineering →
  imputation/scaling/one-hot encoding → regressor.
- Engineered features (TotalSF, TotalBath, HouseAge, has-X flags) and benchmarked three models
  under identical 5-fold cross-validation.
- Packaged the project as a professional GitHub repo with notebooks, modular `src/` code, a PDF
  report, and a deployed Streamlit app.

**Result.** Gradient Boosting achieved CV RMSE 0.1286 (log), R² 0.91, and MAE ≈ $14,900 (8.9%
MAPE) on held-out data — with the engineered TotalSF feature ranked the #1 predictor.

---

## Skills demonstrated (for ATS keyword matching)
Python · pandas · NumPy · scikit-learn · Pipeline · ColumnTransformer · feature engineering ·
cross-validation · Gradient Boosting · Random Forest · regression · EDA · data visualization ·
Streamlit · Git/GitHub · model deployment
