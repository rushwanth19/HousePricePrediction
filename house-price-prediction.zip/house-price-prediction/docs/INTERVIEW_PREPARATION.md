# Interview Preparation — House Price Prediction

Questions an interviewer is likely to ask about *this specific project*, with strong answers.
Know these cold — they turn "a project on your resume" into "a project you clearly own."

## Project walkthrough (the opener)
**Q: Walk me through this project.**
I built a model to predict house sale prices from 79 features on the Ames housing dataset.
After EDA, I built a leak-free scikit-learn pipeline — domain-driven cleaning, feature
engineering, then imputation, scaling, and encoding feeding a regressor. I compared Ridge,
Random Forest, and Gradient Boosting with 5-fold cross-validation; Gradient Boosting won with
a log-RMSE of 0.1286 and R² of 0.91 on held-out data. Finally I deployed it as a Streamlit app.

## Data & target
**Q: Why did you log-transform the target?**
SalePrice was right-skewed (skew ≈ 1.88), which violates the constant-variance assumption and
lets expensive houses dominate the loss. log(1+price) makes it roughly normal, and it matches
the competition metric (RMSE on log price), which penalises proportional error equally across
price ranges.

**Q: How did you handle missing values?**
I split them by meaning. For columns like PoolQC or GarageType, a missing value means the
feature is *absent*, so I filled with "None"/0. LotFrontage I imputed with the neighbourhood
median (nearby homes have similar frontage). Everything else is imputed inside the pipeline —
median for numeric, mode for categorical — so imputation is learned only from training folds.

**Q: Why is imputing inside the pipeline important?**
To prevent data leakage. If I imputed using the whole dataset's statistics before splitting,
information from the validation/test set would leak into training and inflate my scores.

## Feature engineering
**Q: What features did you engineer and did they help?**
Eight, including TotalSF (basement + 1st + 2nd floor area), TotalBath, HouseAge, and has-pool/
garage/fireplace flags. They helped a lot — TotalSF became the single most important feature,
ahead of even OverallQual. It captures total usable space better than any one raw column.

## Modelling
**Q: Why Gradient Boosting over the others?**
It had the lowest cross-validated error. Boosting builds trees sequentially, each correcting
the last's residuals, which captures non-linear feature interactions that a linear model (Ridge)
misses, while being less prone to variance than a single deep tree. Ridge was my fast, linear
baseline; Random Forest sat in between.

**Q: How did you evaluate the model and why those metrics?**
Primary metric was RMSE on log price (the competition standard). For interpretability I also
reported R² (0.91 — variance explained), MAE ($14.9k — average error in dollars), and MAPE
(8.9% — average percentage error). I used a held-out test set plus 5-fold CV so the estimate
wasn't dependent on one split.

**Q: How do you know it's not overfitting?**
The CV scores were stable (low standard deviation across folds), held-out test performance
matched CV, and the residual plot was centred on zero without strong structure.

## Going deeper
**Q: What would you do to improve it?**
Tune XGBoost/LightGBM with Bayesian optimisation, stack models, add SHAP for per-prediction
explanations, and try richer features (interaction terms, polynomial area features).

**Q: How would you deploy and monitor this in production?**
It's already a Streamlit app and the pipeline serialises to a single joblib file that scores
raw input. In production I'd add input validation, monitor feature drift (today's listings vs
the training distribution), track prediction error as actuals arrive, and retrain on a schedule.

**Q: A house comes in with a feature value never seen in training. What happens?**
The OneHotEncoder is set to `handle_unknown="ignore"`, so unseen categories don't crash the
model — they're encoded as all-zeros. Numeric outliers are scaled with training statistics; I'd
flag extreme values for review rather than trusting the estimate blindly.

## Concept checks they may slip in
**Q: Bias-variance trade-off here?**
Ridge was higher bias (underfit the non-linearities); a single deep tree would be high variance.
Gradient Boosting balanced both via many shallow trees with a small learning rate.

**Q: Difference between R² and RMSE?**
RMSE is the error in the target's units (dollars or log-dollars); R² is the proportion of
variance explained (0–1, unitless). RMSE tells you how wrong you are; R² tells you how much
better you are than predicting the mean.
