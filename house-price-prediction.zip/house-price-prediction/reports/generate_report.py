"""Generate the professional project report (PDF) from the real results.

Run:  python reports/generate_report.py
"""
from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Image,
                                Table, TableStyle, PageBreak, HRFlowable)

ROOT = Path(__file__).resolve().parent.parent
FIG = ROOT / "reports" / "figures"
OUT = ROOT / "reports" / "House_Price_Prediction_Report.pdf"

NAVY = colors.HexColor("#0e1b2a")
BLUE = colors.HexColor("#1f6feb")
GREEN = colors.HexColor("#2ea043")
GREY = colors.HexColor("#5b6b7b")

styles = getSampleStyleSheet()
styles.add(ParagraphStyle("TitleBig", parent=styles["Title"], fontSize=26, textColor=NAVY,
                          spaceAfter=6, leading=30))
styles.add(ParagraphStyle("Sub", parent=styles["Normal"], fontSize=12, textColor=GREY,
                          alignment=TA_CENTER, spaceAfter=2))
styles.add(ParagraphStyle("H2", parent=styles["Heading1"], fontSize=15, textColor=BLUE,
                          spaceBefore=14, spaceAfter=6))
styles.add(ParagraphStyle("H3", parent=styles["Heading2"], fontSize=12, textColor=NAVY,
                          spaceBefore=8, spaceAfter=4))
styles.add(ParagraphStyle("Body", parent=styles["Normal"], fontSize=10.5, leading=15,
                          alignment=TA_JUSTIFY, spaceAfter=6))
styles.add(ParagraphStyle("Caption", parent=styles["Normal"], fontSize=8.5, textColor=GREY,
                          alignment=TA_CENTER, spaceAfter=10))

story = []
def P(t, s="Body"): story.append(Paragraph(t, styles[s]))
def gap(h=8): story.append(Spacer(1, h))
def rule(): story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#d8dee4"),
                                    spaceBefore=6, spaceAfter=10))
def figure(name, w=15, cap=""):
    p = FIG / name
    if p.exists():
        img = Image(str(p)); ratio = img.imageHeight / img.imageWidth
        img.drawWidth = w * cm; img.drawHeight = w * cm * ratio
        story.append(img)
        if cap: story.append(Paragraph(cap, styles["Caption"]))

# ---------------- Title ----------------
gap(40)
P("House Price Prediction", "TitleBig")
P("A Machine Learning Approach to Residential Property Valuation", "Sub")
gap(6)
P("Ames Housing Dataset &nbsp;|&nbsp; Advanced Regression", "Sub")
gap(30)
figure("04_key_drivers.png", w=14)
gap(20)
P("Data Science Project Report", "Sub")
P("Author: Rushwanth &nbsp;|&nbsp; Tools: Python, scikit-learn, Streamlit", "Sub")
story.append(PageBreak())

# ---------------- Executive summary ----------------
P("Executive Summary", "H2"); rule()
P("This project builds a machine learning model that predicts the sale price of residential "
  "homes from 79 descriptive features such as size, quality, location, and age. Using the "
  "Ames housing dataset (1,460 records), the final <b>Gradient Boosting</b> model achieves a "
  "cross-validated RMSE of <b>0.1286</b> on the log price scale and an <b>R&#178; of 0.91</b> on a "
  "held-out test set, with a mean absolute error of approximately <b>$14,900</b> (about <b>8.9% "
  "MAPE</b>). A custom-engineered feature, total square footage, emerged as the single strongest "
  "predictor, demonstrating the value of domain-driven feature engineering over raw inputs alone.")

# ---------------- 1 ----------------
P("1. Introduction &amp; Objective", "H2"); rule()
P("Accurately estimating house prices is valuable for buyers, sellers, lenders, and insurers. "
  "Traditional appraisal is manual and subjective; a data-driven model offers consistent, "
  "explainable, and instantaneous estimates. The objective of this project is to predict the "
  "continuous target <i>SalePrice</i> as accurately as possible, measured by the root mean "
  "squared error between the logarithm of predicted and observed prices &mdash; the standard "
  "metric for this problem because it weights proportional errors equally across price ranges.")

# ---------------- 2 ----------------
P("2. Dataset Overview", "H2"); rule()
P("The Ames housing dataset describes residential properties sold in Ames, Iowa. It contains "
  "1,460 training records and 1,459 test records, each with 79 explanatory features spanning "
  "lot and building dimensions, quality and condition ratings, year built, garage and basement "
  "characteristics, and neighbourhood. The features are a mix of 38 numeric and 43 categorical "
  "variables. Nineteen columns contain missing values.")
data = [["Property", "Value"],
        ["Training records", "1,460"],
        ["Test records", "1,459"],
        ["Features", "79 (38 numeric, 43 categorical)"],
        ["Target", "SalePrice (continuous, USD)"],
        ["Columns with missing values", "19"],
        ["Target skewness", "1.88 (right-skewed)"]]
t = Table(data, colWidths=[7*cm, 8*cm])
t.setStyle(TableStyle([
    ("BACKGROUND", (0,0), (-1,0), NAVY), ("TEXTCOLOR", (0,0), (-1,0), colors.white),
    ("FONTSIZE", (0,0), (-1,-1), 9.5), ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
    ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#eef3f8")]),
    ("GRID", (0,0), (-1,-1), 0.5, colors.HexColor("#cdd6e0")),
    ("PADDING", (0,0), (-1,-1), 6)]))
story.append(t); gap(10)

# ---------------- 3 ----------------
P("3. Exploratory Data Analysis", "H2"); rule()
P("<b>Target distribution.</b> SalePrice is strongly right-skewed (skew = 1.88). Applying a "
  "log(1 + price) transform produces a near-normal distribution, which stabilises variance and "
  "aligns the model with the competition's error metric.")
figure("01_target_distribution.png", w=15,
       cap="Figure 1. SalePrice before (left) and after (right) log transformation.")
P("<b>Key drivers.</b> Among numeric features, overall material/finish quality and above-grade "
  "living area correlate most strongly with price, followed by garage capacity and basement area.")
figure("03_top_correlations.png", w=13,
       cap="Figure 2. Top numeric features by correlation with SalePrice.")
figure("04_key_drivers.png", w=15,
       cap="Figure 3. Living area shows a clear linear trend; price rises sharply with quality.")
P("<b>Missing data.</b> Several columns are mostly empty &mdash; but for features like pool "
  "quality, fence, and garage attributes, a missing value means the feature is <i>absent</i> "
  "rather than unknown, which informs the cleaning strategy below.")
figure("05_missing_values.png", w=12,
       cap="Figure 4. Percentage of missing values by column.")
P("<b>Location.</b> Median price varies substantially across neighbourhoods, confirming "
  "location as an important categorical signal.")
figure("06_neighborhood.png", w=16,
       cap="Figure 5. SalePrice distribution by neighbourhood, sorted by median.")

# ---------------- 4 ----------------
P("4. Data Preprocessing &amp; Feature Engineering", "H2"); rule()
P("<b>Domain-driven cleaning.</b> Structural missing values (no pool, garage, or basement) are "
  "filled with the category 'None' or zero, per the data dictionary. Lot frontage is imputed "
  "with the neighbourhood median. Remaining gaps are imputed within the model pipeline "
  "(median for numeric, most-frequent for categorical) to avoid data leakage.")
P("<b>Feature engineering.</b> Eight features were derived to encode domain knowledge:")
P("&bull; <b>TotalSF</b> &mdash; combined basement, first, and second floor area<br/>"
  "&bull; <b>TotalBath</b> &mdash; full + half baths across floors<br/>"
  "&bull; <b>HouseAge</b> and <b>SinceRemodel</b> &mdash; years at time of sale<br/>"
  "&bull; <b>TotalPorchSF</b> and has-pool / has-garage / has-fireplace flags", "Body")
P("<b>Encoding &amp; scaling.</b> Numeric features are standardised; categorical features are "
  "one-hot encoded. After engineering, the model sees 87 features. All steps are wrapped in a "
  "single scikit-learn Pipeline so the saved model scores raw data directly.")

# ---------------- 5 ----------------
P("5. Modelling Approach", "H2"); rule()
P("Three regression models were compared under identical 5-fold cross-validation: a regularised "
  "linear baseline (Ridge), a Random Forest, and Gradient Boosting. The target was modelled on "
  "the log scale, and predictions were exponentiated back to dollars for reporting.")
figure("10_model_comparison.png", w=14,
       cap="Figure 6. Cross-validated RMSE (log scale) &mdash; lower is better.")

# ---------------- 6 ----------------
P("6. Results", "H2"); rule()
P("Gradient Boosting was the clear winner. On a held-out 20% test set its performance was:")
res = [["Metric", "Value", "Interpretation"],
       ["CV RMSE (log)", "0.1286", "Competition metric (RMSLE)"],
       ["R\u00b2 (log scale)", "0.910", "91% of price variance explained"],
       ["MAE", "$14,897", "Average absolute error"],
       ["RMSE", "$25,327", "Penalises large errors"],
       ["MAPE", "8.9%", "Average percentage error"]]
t2 = Table(res, colWidths=[4.5*cm, 4*cm, 7*cm])
t2.setStyle(TableStyle([
    ("BACKGROUND", (0,0), (-1,0), BLUE), ("TEXTCOLOR", (0,0), (-1,0), colors.white),
    ("FONTSIZE", (0,0), (-1,-1), 9.5), ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
    ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#eef3f8")]),
    ("GRID", (0,0), (-1,-1), 0.5, colors.HexColor("#cdd6e0")),
    ("PADDING", (0,0), (-1,-1), 6)]))
story.append(t2); gap(10)
P("The predicted-vs-actual plot shows tight alignment along the diagonal, and residuals are "
  "centred on zero without strong structure &mdash; signs of a well-calibrated model.")
figure("07_pred_vs_actual.png", w=11,
       cap="Figure 7. Predicted vs actual sale price on the held-out test set.")
P("<b>Feature importance.</b> The engineered <b>TotalSF</b> feature is the single most important "
  "predictor, followed by overall quality and total bathrooms &mdash; validating the feature "
  "engineering effort.")
figure("09_feature_importance.png", w=14,
       cap="Figure 8. Top 15 feature importances from the Gradient Boosting model.")

# ---------------- 7 ----------------
P("7. Conclusion &amp; Future Work", "H2"); rule()
P("A Gradient Boosting model with domain-driven preprocessing and feature engineering predicts "
  "house prices to within roughly 9% on average, explaining 91% of price variance. The strongest "
  "drivers &mdash; total area, overall quality, and location &mdash; are intuitive and "
  "explainable, making the model suitable for decision support.")
P("Future improvements include: tuning XGBoost / LightGBM with Bayesian optimisation; stacking "
  "multiple models; adding SHAP explanations for per-prediction transparency; and richer "
  "feature engineering (interaction terms, polynomial area features). The model is deployed as "
  "an interactive Streamlit application for live estimates.")
gap(10); rule()
P("<i>Reproducibility: full code, notebooks, and the trained model are available in the "
  "accompanying GitHub repository. Run <font face='Courier'>python src/train.py</font> to "
  "reproduce the model and <font face='Courier'>streamlit run app/streamlit_app.py</font> to "
  "launch the app.</i>", "Caption")

doc = SimpleDocTemplate(str(OUT), pagesize=A4,
                        topMargin=1.6*cm, bottomMargin=1.6*cm,
                        leftMargin=2*cm, rightMargin=2*cm,
                        title="House Price Prediction Report", author="Rushwanth")
doc.build(story)
print(f"Report written -> {OUT}")
