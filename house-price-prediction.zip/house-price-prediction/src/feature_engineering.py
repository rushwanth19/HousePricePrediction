"""Derived features that capture domain knowledge about house value."""
from __future__ import annotations
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class FeatureEngineer(BaseEstimator, TransformerMixin):
    """Add a handful of high-signal engineered features.

    Implemented as a scikit-learn transformer so it lives inside the pipeline and is
    applied identically to train, validation, and test data.
    """
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X = X.copy()
        # Total square footage across floors + basement — a strong value driver.
        for c in ["TotalBsmtSF", "1stFlrSF", "2ndFlrSF"]:
            if c not in X.columns:
                X[c] = 0
        X["TotalSF"] = X["TotalBsmtSF"] + X["1stFlrSF"] + X["2ndFlrSF"]

        # Total bathrooms (full + half counted as 0.5).
        for c in ["FullBath", "HalfBath", "BsmtFullBath", "BsmtHalfBath"]:
            if c not in X.columns:
                X[c] = 0
        X["TotalBath"] = (X["FullBath"] + 0.5 * X["HalfBath"]
                          + X["BsmtFullBath"] + 0.5 * X["BsmtHalfBath"])

        # Age of the house and years since remodel at time of sale.
        if {"YrSold", "YearBuilt"}.issubset(X.columns):
            X["HouseAge"] = X["YrSold"] - X["YearBuilt"]
        if {"YrSold", "YearRemodAdd"}.issubset(X.columns):
            X["SinceRemodel"] = X["YrSold"] - X["YearRemodAdd"]

        # Total porch area and simple has-X flags.
        porch = ["OpenPorchSF", "EnclosedPorch", "3SsnPorch", "ScreenPorch", "WoodDeckSF"]
        for c in porch:
            if c not in X.columns:
                X[c] = 0
        X["TotalPorchSF"] = X[porch].sum(axis=1)
        X["HasPool"] = (X.get("PoolArea", 0) > 0).astype(int)
        X["HasGarage"] = (X.get("GarageArea", 0) > 0).astype(int)
        X["HasFireplace"] = (X.get("Fireplaces", 0) > 0).astype(int)
        return X
