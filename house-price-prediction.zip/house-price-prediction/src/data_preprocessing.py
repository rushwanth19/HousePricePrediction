"""Load and clean the Ames housing data.

Cleaning rules are driven by the dataset's data dictionary:
  - Some NaNs mean "feature absent" (no pool, no garage) -> fill with "None" or 0.
  - The rest are imputed (median for numeric, mode for categorical) inside the model pipeline.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

from config import (TRAIN_PATH, TEST_PATH, TARGET, ID_COL,
                    NONE_MEANS_ABSENT, ZERO_MEANS_ABSENT)


def load_raw():
    train = pd.read_csv(TRAIN_PATH)
    test = pd.read_csv(TEST_PATH)
    return train, test


def basic_clean(df: pd.DataFrame) -> pd.DataFrame:
    """Apply the domain-driven NaN handling. Safe to call on train and test."""
    df = df.copy()
    for col in NONE_MEANS_ABSENT:
        if col in df.columns:
            df[col] = df[col].fillna("None")
    for col in ZERO_MEANS_ABSENT:
        if col in df.columns:
            df[col] = df[col].fillna(0)
    # LotFrontage: fill by neighbourhood median (houses nearby have similar frontage).
    if "LotFrontage" in df.columns and "Neighborhood" in df.columns:
        df["LotFrontage"] = df.groupby("Neighborhood")["LotFrontage"].transform(
            lambda s: s.fillna(s.median()))
        df["LotFrontage"] = df["LotFrontage"].fillna(df["LotFrontage"].median())
    return df


def get_xy(train: pd.DataFrame):
    """Return features X, log-target y. The target is log1p-transformed because
    SalePrice is right-skewed and the competition metric is RMSE on log price."""
    train = basic_clean(train)
    y = np.log1p(train[TARGET])
    X = train.drop(columns=[TARGET, ID_COL], errors="ignore")
    return X, y


def get_test_features(test: pd.DataFrame):
    test = basic_clean(test)
    ids = test[ID_COL] if ID_COL in test.columns else None
    X = test.drop(columns=[ID_COL], errors="ignore")
    return X, ids
