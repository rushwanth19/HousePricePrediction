"""Central configuration: paths, constants, and column groups."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
MODELS_DIR = ROOT / "models"
REPORTS_DIR = ROOT / "reports"
FIGURES_DIR = REPORTS_DIR / "figures"

TRAIN_PATH = DATA_DIR / "train.csv"
TEST_PATH = DATA_DIR / "test.csv"
MODEL_PATH = MODELS_DIR / "house_price_model.joblib"
SUBMISSION_PATH = ROOT / "submission.csv"

TARGET = "SalePrice"
ID_COL = "Id"
RANDOM_STATE = 42
CV_FOLDS = 5

for _d in (MODELS_DIR, REPORTS_DIR, FIGURES_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# Categorical columns where NaN means "feature is absent" (per the dataset docs),
# so they should be filled with the string "None", not imputed.
NONE_MEANS_ABSENT = [
    "PoolQC", "MiscFeature", "Alley", "Fence", "FireplaceQu", "GarageType",
    "GarageFinish", "GarageQual", "GarageCond", "BsmtQual", "BsmtCond",
    "BsmtExposure", "BsmtFinType1", "BsmtFinType2", "MasVnrType",
]
# Numeric columns where NaN means 0 (e.g. no garage -> 0 cars).
ZERO_MEANS_ABSENT = [
    "GarageYrBlt", "GarageArea", "GarageCars", "BsmtFinSF1", "BsmtFinSF2",
    "BsmtUnfSF", "TotalBsmtSF", "BsmtFullBath", "BsmtHalfBath", "MasVnrArea",
]
