"""Load the saved pipeline and generate a Kaggle-style submission.csv.

Run:  python predict.py
"""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import joblib
import numpy as np
import pandas as pd

from config import MODEL_PATH, SUBMISSION_PATH, TARGET, ID_COL
from data_preprocessing import load_raw, get_test_features


def load_model():
    return joblib.load(MODEL_PATH)


def main():
    _, test_df = load_raw()
    X_test, ids = get_test_features(test_df)
    model = load_model()
    preds_log = model.predict(X_test)
    preds = np.expm1(preds_log)  # invert the log1p transform back to dollars
    out = pd.DataFrame({ID_COL: ids, TARGET: preds})
    out.to_csv(SUBMISSION_PATH, index=False)
    print(f"Wrote {len(out)} predictions -> {SUBMISSION_PATH}")
    print(out.head().to_string(index=False))


if __name__ == "__main__":
    main()
