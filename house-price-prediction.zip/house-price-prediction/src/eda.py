"""Generate the exploratory data analysis figures used in the report and notebooks.

Run:  python eda.py      -> writes PNGs to reports/figures/
"""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from config import FIGURES_DIR, TARGET
from data_preprocessing import load_raw

sns.set_theme(style="whitegrid")
PALETTE = "viridis"


def fig_target_distribution(df):
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))
    sns.histplot(df[TARGET], kde=True, ax=ax[0], color="#2a6f97")
    ax[0].set_title(f"SalePrice (skew = {df[TARGET].skew():.2f})")
    sns.histplot(np.log1p(df[TARGET]), kde=True, ax=ax[1], color="#e76f51")
    ax[1].set_title("log(1 + SalePrice) — used for modelling")
    fig.tight_layout(); fig.savefig(FIGURES_DIR / "01_target_distribution.png", dpi=130)
    plt.close(fig)


def fig_correlation_heatmap(df):
    num = df.select_dtypes(include=np.number)
    top = num.corr()[TARGET].abs().sort_values(ascending=False).head(12).index
    fig, ax = plt.subplots(figsize=(9, 7))
    sns.heatmap(df[top].corr(), annot=True, fmt=".2f", cmap="coolwarm", ax=ax)
    ax.set_title("Correlation of top features with SalePrice")
    fig.tight_layout(); fig.savefig(FIGURES_DIR / "02_correlation_heatmap.png", dpi=130)
    plt.close(fig)


def fig_top_correlations(df):
    num = df.select_dtypes(include=np.number)
    corr = num.corr()[TARGET].drop(TARGET).sort_values(ascending=False).head(10)
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.barplot(x=corr.values, y=corr.index, palette=PALETTE, ax=ax)
    ax.set_title("Top 10 numeric features correlated with SalePrice")
    ax.set_xlabel("Pearson correlation")
    fig.tight_layout(); fig.savefig(FIGURES_DIR / "03_top_correlations.png", dpi=130)
    plt.close(fig)


def fig_scatter_drivers(df):
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))
    sns.scatterplot(data=df, x="GrLivArea", y=TARGET, alpha=0.4, ax=ax[0])
    ax[0].set_title("Living area vs SalePrice")
    sns.boxplot(data=df, x="OverallQual", y=TARGET, palette=PALETTE, ax=ax[1])
    ax[1].set_title("Overall quality vs SalePrice")
    fig.tight_layout(); fig.savefig(FIGURES_DIR / "04_key_drivers.png", dpi=130)
    plt.close(fig)


def fig_missing(df):
    miss = (df.isna().mean() * 100)
    miss = miss[miss > 0].sort_values(ascending=False)
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.barplot(x=miss.values, y=miss.index, palette="rocket", ax=ax)
    ax.set_title("Missing values by column (%)")
    ax.set_xlabel("% missing")
    fig.tight_layout(); fig.savefig(FIGURES_DIR / "05_missing_values.png", dpi=130)
    plt.close(fig)


def fig_neighborhood(df):
    order = df.groupby("Neighborhood")[TARGET].median().sort_values().index
    fig, ax = plt.subplots(figsize=(11, 5))
    sns.boxplot(data=df, x="Neighborhood", y=TARGET, order=order, palette=PALETTE, ax=ax)
    ax.set_title("SalePrice by neighbourhood (sorted by median)")
    ax.tick_params(axis="x", rotation=90)
    fig.tight_layout(); fig.savefig(FIGURES_DIR / "06_neighborhood.png", dpi=130)
    plt.close(fig)


def main():
    train_df, _ = load_raw()
    fig_target_distribution(train_df)
    fig_correlation_heatmap(train_df)
    fig_top_correlations(train_df)
    fig_scatter_drivers(train_df)
    fig_missing(train_df)
    fig_neighborhood(train_df)
    print(f"Saved EDA figures to {FIGURES_DIR}")


if __name__ == "__main__":
    main()
