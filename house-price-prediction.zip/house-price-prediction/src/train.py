"""Train, cross-validate, and compare models; persist the best pipeline.

The full pipeline is: feature engineering -> preprocessing (impute/scale/encode) ->
regressor. Everything is wrapped in one sklearn Pipeline so there's no leakage and the
saved object can score raw data directly.

Run:  python -m src.train      (from repo root)  or  python train.py  (from src/)
"""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.model_selection import cross_val_score, KFold

from config import MODEL_PATH, RANDOM_STATE, CV_FOLDS
from data_preprocessing import load_raw, get_xy
from feature_engineering import FeatureEngineer


def build_preprocessor(X: pd.DataFrame) -> ColumnTransformer:
    numeric = X.select_dtypes(include="number").columns.tolist()
    categorical = X.select_dtypes(exclude="number").columns.tolist()
    num_pipe = Pipeline([("imp", SimpleImputer(strategy="median")),
                         ("sc", StandardScaler())])
    cat_pipe = Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                         ("oh", OneHotEncoder(handle_unknown="ignore"))])
    return ColumnTransformer([("num", num_pipe, numeric),
                              ("cat", cat_pipe, categorical)])


def candidate_models():
    return {
        "Ridge": Ridge(alpha=10.0, random_state=RANDOM_STATE),
        "RandomForest": RandomForestRegressor(
            n_estimators=400, max_depth=None, n_jobs=-1, random_state=RANDOM_STATE),
        "GradientBoosting": GradientBoostingRegressor(
            n_estimators=500, learning_rate=0.05, max_depth=3,
            subsample=0.9, random_state=RANDOM_STATE),
    }


def make_pipeline(model, X_fe: pd.DataFrame) -> Pipeline:
    return Pipeline([
        ("fe", FeatureEngineer()),
        ("prep", build_preprocessor(X_fe)),
        ("model", model),
    ])


def main():
    train_df, _ = load_raw()
    X, y = get_xy(train_df)
    X_fe = FeatureEngineer().fit_transform(X)  # only to learn column types for the preprocessor

    cv = KFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)
    results, best = {}, (None, None, np.inf)

    print(f"Training on {X.shape[0]} rows, {X.shape[1]} raw features "
          f"({X_fe.shape[1]} after engineering)\n")
    for name, model in candidate_models().items():
        pipe = make_pipeline(model, X_fe)
        # RMSE on the log target == the competition's RMSLE.
        scores = cross_val_score(pipe, X, y, cv=cv,
                                 scoring="neg_root_mean_squared_error", n_jobs=-1)
        rmse = -scores.mean()
        results[name] = rmse
        print(f"{name:18s} CV RMSE (log) = {rmse:.5f}  (+/- {scores.std():.5f})")
        if rmse < best[2]:
            best = (name, pipe, rmse)

    best_name, best_pipe, best_rmse = best
    print(f"\nBest model: {best_name}  (CV RMSE log = {best_rmse:.5f})")
    best_pipe.fit(X, y)
    joblib.dump(best_pipe, MODEL_PATH)
    print(f"Saved fitted pipeline -> {MODEL_PATH}")
    return results, best_name, best_rmse


if __name__ == "__main__":
    main()
