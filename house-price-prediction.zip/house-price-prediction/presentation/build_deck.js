const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const path = require("path");
const {
  FaHome, FaBullseye, FaDatabase, FaChartBar, FaCogs, FaRobot,
  FaTrophy, FaRocket, FaLightbulb, FaCheckCircle, FaSearch, FaLayerGroup
} = require("react-icons/fa");

const FIG = path.resolve(__dirname, "..", "reports", "figures");
const OUT = path.resolve(__dirname, "House_Price_Prediction.pptx");

// ---- palette: Ocean / deep navy (matches the app + report) ----
const NAVY = "0E1B2A", DEEP = "102740", BLUE = "1F6FEB", TEAL = "1C7293",
      GREEN = "2EA043", ICE = "CADCFC", WHITE = "FFFFFF", MUTE = "8FA3B8",
      CARD = "16314E", LINE = "24496E";

async function icon(Cmp, color = "FFFFFF", size = 256) {
  const svg = ReactDOMServer.renderToStaticMarkup(
    React.createElement(Cmp, { color: "#" + color, size: String(size) }));
  const png = await sharp(Buffer.from(svg)).png().toBuffer();
  return "image/png;base64," + png.toString("base64");
}
const shadow = () => ({ type: "outer", color: "000000", blur: 8, offset: 3, angle: 90, opacity: 0.28 });

(async () => {
  const p = new pptxgen();
  p.layout = "LAYOUT_WIDE";        // 13.3 x 7.5
  p.author = "Rushwanth";
  p.title = "House Price Prediction";
  const W = 13.3, H = 7.5;

  const ic = {
    home: await icon(FaHome, "FFFFFF"), goal: await icon(FaBullseye, ICE),
    db: await icon(FaDatabase, ICE), eda: await icon(FaSearch, ICE),
    cogs: await icon(FaCogs, ICE), robot: await icon(FaRobot, ICE),
    trophy: await icon(FaTrophy, "FFD66B"), rocket: await icon(FaRocket, ICE),
    bulb: await icon(FaLightbulb, "FFD66B"), check: await icon(FaCheckCircle, GREEN),
    chart: await icon(FaChartBar, ICE), layer: await icon(FaLayerGroup, ICE),
  };

  const eyebrow = (s, t, icimg) => {
    s.addImage({ data: icimg, x: 0.6, y: 0.55, w: 0.42, h: 0.42 });
    s.addText(t, { x: 1.15, y: 0.5, w: 11, h: 0.55, fontSize: 26, bold: true,
      color: NAVY, fontFace: "Cambria", valign: "middle", margin: 0 });
  };

  // ---------- 1. TITLE ----------
  let s = p.addSlide(); s.background = { color: NAVY };
  s.addImage({ data: ic.home, x: 6.35, y: 1.0, w: 0.62, h: 0.62 });
  s.addText("HOUSE PRICE PREDICTION", { x: 0.5, y: 1.9, w: 12.3, h: 1.0, align: "center",
    fontSize: 46, bold: true, color: WHITE, fontFace: "Cambria", charSpacing: 1 });
  s.addText("A Machine Learning Approach to Residential Property Valuation",
    { x: 0.5, y: 2.95, w: 12.3, h: 0.5, align: "center", fontSize: 18, color: ICE, fontFace: "Calibri" });
  // stat strip
  const strip = [["0.91", "Test R\u00B2"], ["$14.9k", "Mean error"], ["8.9%", "MAPE"], ["1,460", "Homes"]];
  strip.forEach((d, i) => {
    const x = 1.85 + i * 2.55;
    s.addShape(p.shapes.ROUNDED_RECTANGLE, { x, y: 4.2, w: 2.2, h: 1.3, fill: { color: DEEP },
      line: { color: LINE, width: 1 }, rectRadius: 0.1, shadow: shadow() });
    s.addText(d[0], { x, y: 4.42, w: 2.2, h: 0.65, align: "center", fontSize: 30, bold: true, color: GREEN, fontFace: "Cambria" });
    s.addText(d[1], { x, y: 5.06, w: 2.2, h: 0.35, align: "center", fontSize: 12, color: MUTE, fontFace: "Calibri", charSpacing: 1 });
  });
  s.addText("Ames Housing Dataset   |   Python · scikit-learn · Streamlit   |   Rushwanth",
    { x: 0.5, y: 6.6, w: 12.3, h: 0.4, align: "center", fontSize: 12, color: MUTE, fontFace: "Calibri" });

  // ---------- 2. PROBLEM & OBJECTIVE ----------
  s = p.addSlide(); s.background = { color: WHITE };
  eyebrow(s, "The Problem & Objective", ic.goal);
  const probCards = [
    ["Why it matters", "Home valuation is slow, manual, and subjective. Buyers, sellers, and lenders need fast, consistent, explainable estimates."],
    ["The task", "Predict a home's SalePrice from 79 features describing its size, quality, location, and age."],
    ["Success metric", "RMSE on log(price) \u2014 the standard metric, which treats proportional errors equally across price ranges."],
  ];
  probCards.forEach((c, i) => {
    const x = 0.6 + i * 4.15;
    s.addShape(p.shapes.ROUNDED_RECTANGLE, { x, y: 1.7, w: 3.85, h: 3.6, fill: { color: "F4F8FC" },
      line: { color: "DCE6F0", width: 1 }, rectRadius: 0.08, shadow: shadow() });
    s.addText(c[0], { x: x + 0.3, y: 2.0, w: 3.25, h: 0.6, fontSize: 18, bold: true, color: BLUE, fontFace: "Cambria" });
    s.addText(c[1], { x: x + 0.3, y: 2.7, w: 3.25, h: 2.4, fontSize: 14, color: "33414f", fontFace: "Calibri", valign: "top", lineSpacingMultiple: 1.1 });
  });
  s.addText("Goal: predict SalePrice as accurately as possible, measured by RMSLE.",
    { x: 0.6, y: 5.7, w: 12, h: 0.5, fontSize: 15, italic: true, color: NAVY, fontFace: "Calibri" });

  // ---------- 3. DATASET ----------
  s = p.addSlide(); s.background = { color: WHITE };
  eyebrow(s, "Dataset Overview", ic.db);
  const stats = [["1,460", "Training homes"], ["79", "Features"], ["38 / 43", "Numeric / categorical"], ["19", "Cols with missing data"]];
  stats.forEach((d, i) => {
    const x = 0.6 + i * 3.1;
    s.addShape(p.shapes.ROUNDED_RECTANGLE, { x, y: 1.7, w: 2.85, h: 1.7, fill: { color: NAVY }, rectRadius: 0.1, shadow: shadow() });
    s.addText(d[0], { x, y: 1.92, w: 2.85, h: 0.8, align: "center", fontSize: 30, bold: true, color: WHITE, fontFace: "Cambria" });
    s.addText(d[1], { x, y: 2.72, w: 2.85, h: 0.5, align: "center", fontSize: 12.5, color: ICE, fontFace: "Calibri" });
  });
  s.addText("The Ames, Iowa housing dataset \u2014 a richer, modern alternative to the classic Boston housing data.",
    { x: 0.6, y: 3.7, w: 12, h: 0.5, fontSize: 15, color: "33414f", fontFace: "Calibri" });
  s.addText([
    { text: "Feature families: ", options: { bold: true, color: NAVY } },
    { text: "lot & building size, overall quality/condition, year built & remodelled, basement & garage, neighbourhood, sale type.", options: { color: "33414f" } },
  ], { x: 0.6, y: 4.3, w: 12, h: 0.8, fontSize: 14, fontFace: "Calibri", lineSpacingMultiple: 1.1 });
  s.addImage({ path: path.join(FIG, "01_target_distribution.png"), x: 0.9, y: 5.0, w: 11.5, h: 2.15, sizing: { type: "contain", w: 11.5, h: 2.15 } });

  // ---------- 4. EDA ----------
  s = p.addSlide(); s.background = { color: WHITE };
  eyebrow(s, "Exploratory Data Analysis", ic.eda);
  s.addImage({ path: path.join(FIG, "03_top_correlations.png"), x: 0.55, y: 1.65, w: 6.2, h: 3.9, sizing: { type: "contain", w: 6.2, h: 3.9 } });
  const insights = [
    "SalePrice is right-skewed (skew 1.88) \u2192 modelled on the log scale.",
    "Overall quality and living area are the strongest numeric drivers.",
    "Many 'missing' values are structural \u2014 they mean the feature is absent.",
    "Median price varies sharply by neighbourhood (a strong categorical signal).",
  ];
  s.addText(insights.map((t) => ({ text: t, options: { bullet: { code: "2022" }, breakLine: true, paraSpaceAfter: 10 } })),
    { x: 7.0, y: 1.9, w: 5.7, h: 3.6, fontSize: 14.5, color: "2b3a48", fontFace: "Calibri", valign: "top" });
  s.addImage({ path: path.join(FIG, "06_neighborhood.png"), x: 7.0, y: 5.3, w: 5.7, h: 1.95, sizing: { type: "contain", w: 5.7, h: 1.95 } });

  // ---------- 5. PREPROCESSING & FEATURE ENGINEERING ----------
  s = p.addSlide(); s.background = { color: WHITE };
  eyebrow(s, "Preprocessing & Feature Engineering", ic.cogs);
  const steps = [
    ["Domain-driven cleaning", "Structural NaNs (no pool/garage/basement) \u2192 'None' or 0. Lot frontage filled by neighbourhood median."],
    ["Pipeline imputation", "Remaining gaps imputed inside the pipeline \u2014 median for numeric, mode for categorical \u2014 so there's no leakage."],
    ["8 engineered features", "TotalSF, TotalBath, HouseAge, SinceRemodel, TotalPorchSF, and has-pool/garage/fireplace flags."],
    ["Encode & scale", "Standardise numerics, one-hot encode categoricals \u2192 87 features feed the model."],
  ];
  steps.forEach((c, i) => {
    const x = 0.6 + (i % 2) * 6.15, y = 1.75 + Math.floor(i / 2) * 2.45;
    s.addShape(p.shapes.ROUNDED_RECTANGLE, { x, y, w: 5.8, h: 2.15, fill: { color: "F4F8FC" }, line: { color: "DCE6F0", width: 1 }, rectRadius: 0.08, shadow: shadow() });
    s.addShape(p.shapes.OVAL, { x: x + 0.25, y: y + 0.25, w: 0.7, h: 0.7, fill: { color: BLUE } });
    s.addText(`${i + 1}`, { x: x + 0.25, y: y + 0.25, w: 0.7, h: 0.7, align: "center", valign: "middle", fontSize: 24, bold: true, color: WHITE, fontFace: "Cambria" });
    s.addText(c[0], { x: x + 1.15, y: y + 0.22, w: 4.4, h: 0.55, fontSize: 16, bold: true, color: NAVY, fontFace: "Cambria" });
    s.addText(c[1], { x: x + 1.15, y: y + 0.78, w: 4.45, h: 1.2, fontSize: 12.5, color: "33414f", fontFace: "Calibri", valign: "top", lineSpacingMultiple: 1.05 });
  });

  // ---------- 6. MODELING (native chart) ----------
  s = p.addSlide(); s.background = { color: WHITE };
  eyebrow(s, "Modelling Approach", ic.robot);
  s.addText("Three models compared under identical 5-fold cross-validation (RMSE on log price, lower is better):",
    { x: 0.6, y: 1.55, w: 12, h: 0.5, fontSize: 14.5, color: "33414f", fontFace: "Calibri" });
  s.addChart(p.charts.BAR, [{ name: "CV RMSE", labels: ["Ridge", "Random Forest", "Gradient Boosting"], values: [0.1441, 0.1425, 0.1286] }], {
    x: 0.7, y: 2.2, w: 7.4, h: 4.7, barDir: "bar", chartColors: [TEAL, TEAL, GREEN],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: "1E293B", dataLabelFontSize: 13, dataLabelFormatCode: "0.0000",
    catAxisLabelColor: "33414f", catAxisLabelFontSize: 13, valAxisLabelColor: "8FA3B8",
    valAxisMinVal: 0, valAxisMaxVal: 0.16, valGridLine: { color: "E2E8F0", size: 0.5 }, catGridLine: { style: "none" }, showLegend: false,
    chartArea: { fill: { color: "FFFFFF" } },
  });
  s.addShape(p.shapes.ROUNDED_RECTANGLE, { x: 8.5, y: 2.4, w: 4.2, h: 4.2, fill: { color: NAVY }, rectRadius: 0.1, shadow: shadow() });
  s.addImage({ data: ic.trophy, x: 10.25, y: 2.7, w: 0.7, h: 0.7 });
  s.addText("Winner", { x: 8.5, y: 3.45, w: 4.2, h: 0.4, align: "center", fontSize: 14, color: ICE, fontFace: "Calibri", charSpacing: 2 });
  s.addText("Gradient\nBoosting", { x: 8.5, y: 3.85, w: 4.2, h: 1.1, align: "center", fontSize: 26, bold: true, color: WHITE, fontFace: "Cambria" });
  s.addText("CV RMSE 0.1286", { x: 8.5, y: 5.05, w: 4.2, h: 0.5, align: "center", fontSize: 18, bold: true, color: GREEN, fontFace: "Cambria" });
  s.addText("500 trees · lr 0.05 · depth 3", { x: 8.5, y: 5.6, w: 4.2, h: 0.5, align: "center", fontSize: 12.5, color: MUTE, fontFace: "Calibri" });

  // ---------- 7. RESULTS ----------
  s = p.addSlide(); s.background = { color: WHITE };
  eyebrow(s, "Results", ic.trophy);
  const res = [["0.910", "R\u00B2 (variance explained)"], ["$14,897", "Mean absolute error"], ["8.9%", "Mean % error (MAPE)"], ["0.1286", "CV RMSE (log)"]];
  res.forEach((d, i) => {
    const x = 0.6 + i * 3.1;
    s.addShape(p.shapes.ROUNDED_RECTANGLE, { x, y: 1.7, w: 2.85, h: 1.6, fill: { color: i === 0 ? GREEN : CARD }, rectRadius: 0.1, shadow: shadow() });
    s.addText(d[0], { x, y: 1.9, w: 2.85, h: 0.75, align: "center", fontSize: 28, bold: true, color: WHITE, fontFace: "Cambria" });
    s.addText(d[1], { x, y: 2.66, w: 2.85, h: 0.5, align: "center", fontSize: 11.5, color: ICE, fontFace: "Calibri" });
  });
  s.addImage({ path: path.join(FIG, "07_pred_vs_actual.png"), x: 0.8, y: 3.5, w: 5.6, h: 3.7, sizing: { type: "contain", w: 5.6, h: 3.7 } });
  s.addImage({ path: path.join(FIG, "09_feature_importance.png"), x: 6.7, y: 3.5, w: 6.0, h: 3.7, sizing: { type: "contain", w: 6.0, h: 3.7 } });
  s.addText("Tight diagonal fit and zero-centred residuals \u2014 the engineered TotalSF is the #1 driver.",
    { x: 0.6, y: 7.05, w: 12, h: 0.35, fontSize: 12, italic: true, color: NAVY, fontFace: "Calibri", align: "center" });

  // ---------- 8. DEPLOYMENT ----------
  s = p.addSlide(); s.background = { color: NAVY };
  s.addImage({ data: ic.rocket, x: 0.6, y: 0.55, w: 0.42, h: 0.42 });
  s.addText("Live App & Deployment", { x: 1.15, y: 0.5, w: 11, h: 0.55, fontSize: 26, bold: true, color: WHITE, fontFace: "Cambria", valign: "middle", margin: 0 });
  const dep = [
    ["Interactive Streamlit app", "Move sliders for size, quality, garage, and location \u2192 instant price estimate with a confidence band."],
    ["One-click reproducibility", "python src/train.py rebuilds the model; streamlit run app/streamlit_app.py launches the UI."],
    ["Cloud-ready", "Deploys free to Streamlit Community Cloud or Hugging Face Spaces \u2014 configs included in /deployment."],
  ];
  dep.forEach((c, i) => {
    const y = 1.75 + i * 1.7;
    s.addShape(p.shapes.ROUNDED_RECTANGLE, { x: 0.8, y, w: 11.7, h: 1.45, fill: { color: DEEP }, line: { color: LINE, width: 1 }, rectRadius: 0.08, shadow: shadow() });
    s.addImage({ data: ic.check, x: 1.1, y: y + 0.45, w: 0.55, h: 0.55 });
    s.addText(c[0], { x: 1.9, y: y + 0.2, w: 10.3, h: 0.5, fontSize: 17, bold: true, color: WHITE, fontFace: "Cambria" });
    s.addText(c[1], { x: 1.9, y: y + 0.72, w: 10.3, h: 0.6, fontSize: 13, color: ICE, fontFace: "Calibri" });
  });

  // ---------- 9. CONCLUSION ----------
  s = p.addSlide(); s.background = { color: NAVY };
  s.addImage({ data: ic.bulb, x: 5.95, y: 0.85, w: 0.62, h: 0.62 });
  s.addText("Key Takeaways", { x: 0.5, y: 1.55, w: 12.3, h: 0.7, align: "center", fontSize: 30, bold: true, color: WHITE, fontFace: "Cambria" });
  const take = [
    "Gradient Boosting predicts price within ~9% on average (R\u00B2 = 0.91).",
    "Domain-driven cleaning + feature engineering beat raw inputs \u2014 TotalSF is the top predictor.",
    "A leak-free scikit-learn pipeline makes the model reproducible and deployable.",
    "Next: XGBoost/LightGBM tuning, model stacking, and SHAP explanations.",
  ];
  s.addText(take.map((t) => ({ text: t, options: { bullet: { code: "2022" }, breakLine: true, paraSpaceAfter: 16 } })),
    { x: 2.2, y: 2.6, w: 9, h: 3.2, fontSize: 17, color: ICE, fontFace: "Calibri", valign: "top" });
  s.addText("Thank you  \u2014  Rushwanth", { x: 0.5, y: 6.5, w: 12.3, h: 0.5, align: "center", fontSize: 16, bold: true, color: WHITE, fontFace: "Cambria" });

  await p.writeFile({ fileName: OUT });
  console.log("Deck written ->", OUT);
})();
