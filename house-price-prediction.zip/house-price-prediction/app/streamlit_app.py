"""
🏠 House Price Predictor — Streamlit web app.

Loads the trained pipeline and lets a user estimate a house's sale price from a handful of
key inputs. The full 79-column feature row is reconstructed from sensible training defaults,
so the user only adjusts what matters.

Run from the repo root:
    streamlit run app/streamlit_app.py
"""
from __future__ import annotations
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import joblib
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
# The saved pipeline contains a custom FeatureEngineer transformer defined in src/,
# so src/ must be importable for joblib to unpickle the model.
sys.path.append(str(ROOT / "src"))
MODEL_PATH = ROOT / "models" / "house_price_model.joblib"
TRAIN_PATH = ROOT / "data" / "train.csv"

st.set_page_config(page_title="House Price Predictor", page_icon="🏠", layout="wide")

# --------------------------------------------------------------------------- #
# Styling
# --------------------------------------------------------------------------- #
st.markdown("""
<style>
  .stApp { background: linear-gradient(180deg,#0e1b2a 0%, #102740 100%); }
  h1, h2, h3, h4, p, label, .stMarkdown { color: #f4f3ee !important; }
  .price-card {
    background: linear-gradient(135deg,#1f6feb 0%, #2ea043 100%);
    border-radius: 18px; padding: 28px 32px; text-align:center; margin: 8px 0 4px;
    box-shadow: 0 10px 30px rgba(0,0,0,.35);
  }
  .price-card .label { font-size: .9rem; letter-spacing:.14em; text-transform:uppercase; opacity:.85; }
  .price-card .value { font-size: 3rem; font-weight: 800; line-height: 1.1; }
  .metric-pill {
    background:#16314e; border:1px solid #24496e; border-radius:12px; padding:14px 18px; text-align:center;
  }
  .metric-pill .m { font-size:1.5rem; font-weight:700; color:#7ee0a2 !important; }
  .metric-pill .l { font-size:.72rem; letter-spacing:.1em; text-transform:uppercase; opacity:.8; }
  div[data-testid="stExpander"] { background:#13283f; border-radius:12px; border:1px solid #24496e; }
</style>
""", unsafe_allow_html=True)


# --------------------------------------------------------------------------- #
# Load model + training defaults
# --------------------------------------------------------------------------- #
@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)


@st.cache_data
def load_defaults():
    """A single representative row (median for numbers, mode for text) for every raw column."""
    df = pd.read_csv(TRAIN_PATH).drop(columns=["Id", "SalePrice"], errors="ignore")
    defaults = {}
    for col in df.columns:
        if pd.api.types.is_numeric_dtype(df[col]):
            defaults[col] = float(df[col].median())
        else:
            defaults[col] = df[col].mode(dropna=True).iloc[0]
    options = {c: sorted(df[c].dropna().unique().tolist())
               for c in df.select_dtypes(exclude=np.number).columns}
    ranges = {c: (float(df[c].min()), float(df[c].max()), float(df[c].median()))
              for c in df.select_dtypes(include=np.number).columns}
    return defaults, options, ranges, df


try:
    model = load_model()
    defaults, options, ranges, raw_df = load_defaults()
except Exception as exc:
    st.error(f"Could not load the model or data. Train it first with `python src/train.py`.\n\n{exc}")
    st.stop()


# --------------------------------------------------------------------------- #
# Header
# --------------------------------------------------------------------------- #
st.title("🏠 House Price Predictor")
st.caption("Estimate a home's sale price from its key characteristics. "
           "Powered by a Gradient Boosting model trained on the Ames housing dataset.")

m1, m2, m3, m4 = st.columns(4)
for col, val, lab in [(m1, "0.910", "Test R²"), (m2, "$14.9k", "Mean abs error"),
                      (m3, "8.9%", "Mean error (MAPE)"), (m4, "0.1286", "CV RMSE (log)")]:
    col.markdown(f"<div class='metric-pill'><div class='m'>{val}</div>"
                 f"<div class='l'>{lab}</div></div>", unsafe_allow_html=True)

st.divider()

# --------------------------------------------------------------------------- #
# Inputs — the high-signal features, grouped in expanders
# --------------------------------------------------------------------------- #
left, right = st.columns([1.1, 1])

with left:
    st.subheader("Describe the house")

    with st.expander("📐 Size & quality", expanded=True):
        c1, c2 = st.columns(2)
        overall_qual = c1.slider("Overall quality (1–10)", 1, 10, 7)
        gr_liv = c2.number_input("Above-grade living area (sq ft)", 300, 6000,
                                 int(ranges["GrLivArea"][2]), step=50)
        bsmt = c1.number_input("Total basement (sq ft)", 0, 4000,
                               int(ranges["TotalBsmtSF"][2]), step=50)
        first = c2.number_input("1st floor (sq ft)", 300, 4000,
                                int(ranges["1stFlrSF"][2]), step=50)
        second = c1.number_input("2nd floor (sq ft)", 0, 3000,
                                 int(ranges["2ndFlrSF"][2]), step=50)
        lot = c2.number_input("Lot area (sq ft)", 1000, 60000,
                              int(ranges["LotArea"][2]), step=500)

    with st.expander("🛏️ Rooms & baths"):
        c1, c2 = st.columns(2)
        full_bath = c1.slider("Full bathrooms", 0, 4, 2)
        half_bath = c2.slider("Half bathrooms", 0, 3, 1)
        bedrooms = c1.slider("Bedrooms above grade", 0, 8, 3)
        tot_rooms = c2.slider("Total rooms above grade", 2, 14, 6)
        fireplaces = c1.slider("Fireplaces", 0, 4, 1)

    with st.expander("🚗 Garage & year"):
        c1, c2 = st.columns(2)
        garage_cars = c1.slider("Garage capacity (cars)", 0, 4, 2)
        garage_area = c2.number_input("Garage area (sq ft)", 0, 1500,
                                      int(ranges["GarageArea"][2]), step=20)
        year_built = c1.slider("Year built", 1872, 2010, int(ranges["YearBuilt"][2]))
        year_remod = c2.slider("Year remodelled", 1950, 2010, int(ranges["YearRemodAdd"][2]))
        yr_sold = c1.slider("Year sold", 2006, 2010, 2008)

    with st.expander("📍 Location & type"):
        neighborhood = st.selectbox("Neighbourhood", options["Neighborhood"],
                                    index=options["Neighborhood"].index(defaults["Neighborhood"]))
        c1, c2 = st.columns(2)
        bldg = c1.selectbox("Building type", options["BldgType"],
                            index=options["BldgType"].index(defaults["BldgType"]))
        style = c2.selectbox("House style", options["HouseStyle"],
                            index=options["HouseStyle"].index(defaults["HouseStyle"]))
        central_air = c1.selectbox("Central air", options["CentralAir"],
                            index=options["CentralAir"].index(defaults["CentralAir"]))
        kitchen_qual = c2.selectbox("Kitchen quality", options["KitchenQual"],
                            index=options["KitchenQual"].index(defaults["KitchenQual"]))

# Build the full feature row from defaults, then override with user inputs.
row = dict(defaults)
row.update({
    "OverallQual": overall_qual, "GrLivArea": gr_liv, "TotalBsmtSF": bsmt,
    "1stFlrSF": first, "2ndFlrSF": second, "LotArea": lot,
    "FullBath": full_bath, "HalfBath": half_bath, "BedroomAbvGr": bedrooms,
    "TotRmsAbvGrd": tot_rooms, "Fireplaces": fireplaces,
    "GarageCars": garage_cars, "GarageArea": garage_area,
    "YearBuilt": year_built, "YearRemodAdd": year_remod, "YrSold": yr_sold,
    "Neighborhood": neighborhood, "BldgType": bldg, "HouseStyle": style,
    "CentralAir": central_air, "KitchenQual": kitchen_qual,
})
input_df = pd.DataFrame([row])

with right:
    st.subheader("Estimated sale price")
    if st.button("💰 Predict price", use_container_width=True, type="primary"):
        pred = float(np.expm1(model.predict(input_df)[0]))
        st.markdown(f"<div class='price-card'><div class='label'>Predicted value</div>"
                    f"<div class='value'>${pred:,.0f}</div></div>", unsafe_allow_html=True)
        lo, hi = pred * 0.911, pred * 1.089  # ± MAPE band
        st.caption(f"Typical range (± mean error): **${lo:,.0f} – ${hi:,.0f}**")
    else:
        st.info("Set the house details on the left, then click **Predict price**.")

    st.markdown("##### What's driving prices?")
    fi_path = ROOT / "reports" / "figures" / "09_feature_importance.png"
    if fi_path.exists():
        st.image(str(fi_path), use_container_width=True)

st.divider()
st.caption("Model: Gradient Boosting · target log-transformed · 87 features after engineering. "
           "Built for educational/portfolio use on the Ames housing dataset.")
